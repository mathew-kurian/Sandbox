These folders will probably be changed soon to a more SVN-friendly scheme.

Here's the description for the main SVN folders:

/as2_fl7   : Tweener source classes, Actionscript 2 version, *without* advanced features such as filters. Must be used on AS2 projects (when targeting Flash Player 7+, and Flash Lite Player 2+).
/as2       : Tweener source classes, Actionscript 2 version. Must be used on AS2 projects (when targeting Flash Player 8+).
/as3       : Tweener source classes, Actionscript 3 version. Must be used on AS3 projects (when targeting Flash Player 9+, including when using Flex).
/as3_swc   : Same as /as3, but in SWC form.

/branches  : Other code branches, for experiment and test purposes. They're not guaranteed to work, so nobody should usually download them.

/docs      : Documentation, in various shapes and forms (HTML, Flash IDE, Help Toc, etc).
/examples  : Example files with source.

For more information on which version to download, please visit:
http://code.google.com/p/tweener/wiki/WhichVersionToDownload
