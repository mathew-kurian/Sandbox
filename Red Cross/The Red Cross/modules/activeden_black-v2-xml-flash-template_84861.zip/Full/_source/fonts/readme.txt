--------------------------------------
ATTENTION
--------------------------------------

Fonts being used in this template are:

"uni 05_53" and "pf_tempesta_seven condensed"


--------------------------------------
Both are available for free:
--------------------------------------

To use the uni 05_53 font download it for free from www.miniml.com and install on your computer.

To use the pf_tempesta_seven condensed font download it for free from www.dafont.com and install on your computer.

--------------------------------------
Tip
--------------------------------------

Both of these fonts are pixel fonts and should be kept at a point size of 8. Otherwise they will look blurry.
If you intend to increase font size in the xml or switch to a non pixel font I suggest changing the dynamic text fields setting from bitmap to anti alias for readability.
