<?php
/*
	OXYLUS Development web framework
	copyright (c) 2002-2008 OXYLUS Development
		web:  www.oxylus-development.com
		mail: support@oxylus-development.com

	$Id: name.php,v 0.0.1 dd/mm/yyyy hh:mm:ss oxylus Exp $
	description
*/

// dependencies

if (!$_TSM["PUB.ADMIN.LOGO"]) {
	$_TSM["PUB.ADMIN.LOGO"]  = "logo.gif";
}

?>
