<?php
	/**
	* TemplatePlazza
	**/
	defined('_JEXEC') or die('Restricted access');
	require(JModuleHelper::getLayoutPath('mod_tpplayer'));
?>
