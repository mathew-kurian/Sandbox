<?php

// no direct access
defined('_JEXEC') or die('Restricted access');

?>

<form action="index.php" method="get">
<div>
	Theme
	<br />
	<?php echo str_replace("params[tp_templatetheme]", "tptheme", $arrParams['tp_templatetheme'][1]); ?>
</div>

<div>
	Primary Font Family
	<br />
	<?php echo str_replace("params[tp_primaryfontfam]", "ffp", $arrParams['tp_primaryfontfam'][1]); ?>
</div>

<div>
	Secondary Font Family
	<br />
	<?php echo str_replace("params[tp_secondaryfontfam]", "ffs", $arrParams['tp_secondaryfontfam'][1]); ?>
</div>

<div>
	Tertiery Font Family
	<br />
	<?php echo str_replace("params[tp_tertieryfontfam]", "fft", $arrParams['tp_tertieryfontfam'][1]); ?>
</div>

<div>
	Primary Font Size
	<br />
	<?php echo str_replace("params[tp_primaryfontsize]", "fsp", $arrParams['tp_primaryfontsize'][1]); ?>
</div>

<div>
	Secondary Font Size
	<br />
	<?php echo str_replace("params[tp_secondaryfontsize]", "fss", $arrParams['tp_secondaryfontsize'][1]); ?>
</div>

<div>
	Tertiery Font Size
	<br />
	<?php echo str_replace("params[tp_tertieryfontsize]", "fst", $arrParams['tp_tertieryfontsize'][1]); ?>
</div>
<input type="submit" value="Apply" class="button" />
</form>